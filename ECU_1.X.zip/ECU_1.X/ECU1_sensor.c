/*
 * File:   ECU1_sensor.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:12 PM
 */

#include <xc.h>
#include "ECU1_sensor.h"
#include "DIGITAL_KEYPAD.h"
#include "ADC.h"
#include "CAN.h"
#include "msg_ID.h"

uint16_t get_speed()
{
    return read_adc(CHANNEL4) / 10.23;    // Read and scale ADC value to speed
}

unsigned char get_gear_pos(void)
{
    // Implement the gear function   
    
    static unsigned int gear_pos = 0;   // Store current gear position
    
    unsigned char key = read_digital_keypad(STATE_CHANGE);   // Read keypad input
     
    if(key == GEAR_UP)
    {
        if(gear_pos < MAX_GEAR)   // Check maximum gear limit
        {
            gear_pos++;   // Increase gear
        }
    }
    else if(key == GEAR_DOWN)
    {
        if(gear_pos > 0)   // Check minimum gear limit
        {
            gear_pos--;   // Decrease gear
        }
    }
    
    return gear_pos;   // Return current gear position
}