/*
 * File:   ADC.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:10 PM
 */


#include <xc.h>
#include "ADC.h"

void init_adc(void)
{
	ADFM = 1;          // Right justify ADC result

	ACQT2 = 0;         // Acquisition time bit 2
	ACQT1 = 1;         // Acquisition time bit 1
	ACQT0 = 0;         // Acquisition time bit 0

	ADCS0 = 0;         // ADC conversion clock bit 0
	ADCS1 = 1;         // ADC conversion clock bit 1
	ADCS2 = 0;         // ADC conversion clock bit 2

	GODONE = 0;        // Clear ADC conversion status bit

	VCFG1 = 0;         // Configure Vref- as VSS
	
	VCFG0 = 0;         // Configure Vref+ as VDD

	ADRESH = 0;        // Clear ADC result high register
	ADRESL = 0;        // Clear ADC result low register

	ADON = 1;          // Enable ADC module
}

unsigned short read_adc(unsigned char channel)
{
	unsigned short reg_val;   // Variable to store ADC result

	ADCON0 = (ADCON0 & 0xC3) | (channel << 2);   // Select ADC channel

	GO = 1;                  // Start ADC conversion
	while (GO);              // Wait until conversion completes
	
	reg_val = (ADRESH << 8) | ADRESL;   // Combine high and low result bytes

	return reg_val;          // Return ADC result
}