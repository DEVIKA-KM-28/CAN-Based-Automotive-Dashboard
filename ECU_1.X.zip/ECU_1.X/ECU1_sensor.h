/* 
 * File:   ECU1_sensor.h
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:12 PM
 */

#ifndef ECU1_SENSOR_H
#define	ECU1_SENSOR_H

#include <stdint.h>          // Standard integer type definitions
#include "DIGITAL_KEYPAD.h" // Header file for digital keypad functions
#include <xc.h>              // PIC microcontroller header file

#define MAX_GEAR 6                  // Maximum gear value
#define SPEED_ADC_CHANNEL 0x04      // ADC channel used for speed sensor
#define GEAR_UP             SWITCH1 // Key assigned for gear up
#define GEAR_DOWN           SWITCH2 // Key assigned for gear down
#define COLLISION           SWITCH3 // Key assigned for collision detection

uint16_t get_speed();        // Function to get vehicle speed
unsigned char get_gear_pos(); // Function to get current gear position

#endif	/* ECU1_SENSOR_H */
