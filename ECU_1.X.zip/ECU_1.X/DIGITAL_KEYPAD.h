/* 
 * File:   MATRIX_KEYPAD.h
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:11 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define DIGITAL_KEYPAD_H

#define LEVEL					     	0   // Level detection mode
#define STATE_CHANGE			       	1   // State change detection mode

#define KEY_PORT					PORTC   // Port connected to keypad

#define SWITCH1					0x0E   // Switch 1 pressed value
#define SWITCH2					0x0D   // Switch 2 pressed value
#define SWITCH3					0x0B   // Switch 3 pressed value
#define SWITCH4					0x07   // Switch 4 pressed value
#define ALL_RELEASED					0x0F   // All switches released value

#define INPUT_PINS					0x0F   // Configure lower 4 pins as input

void init_digital_keypad(void);   // Function to initialize digital keypad
unsigned char read_digital_keypad(unsigned char detection_type);   // Function to read keypad input

#endif