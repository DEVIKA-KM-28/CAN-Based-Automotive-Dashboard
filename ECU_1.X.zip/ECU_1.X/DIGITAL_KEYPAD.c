/*
 * File:   MATRIX_KEYPAD.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:11 PM
 */


#include <xc.h>
#include "DIGITAL_KEYPAD.h"

void init_digital_keypad(void)
{
	TRISC = TRISC | INPUT_PINS;   // Configure keypad pins as input
}

unsigned char read_digital_keypad(unsigned char detection_type)
{
	static unsigned char once = 1;   // Variable to detect single key press

	if (detection_type == STATE_CHANGE)
	{
		if (((KEY_PORT & INPUT_PINS) != ALL_RELEASED) && once)   // Check key press
		{
			once = 0;   // Prevent repeated detection

			return (KEY_PORT & INPUT_PINS);   // Return pressed key value
		}
		else if ((KEY_PORT & INPUT_PINS) == ALL_RELEASED)   // Check all keys released
		{
			once = 1;   // Reset detection flag
		}
	}
	else if (detection_type == LEVEL)
	{
		return (KEY_PORT & INPUT_PINS);   // Return current key level
	}

	return 0xFF;   // Return invalid value if no key detected
}