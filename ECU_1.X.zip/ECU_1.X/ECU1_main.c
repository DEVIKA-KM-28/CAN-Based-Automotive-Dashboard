/*
 * File:   ECU1_main.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:11 PM
 */


#include <xc.h>
#include "ADC.h"
#include "CAN.h"
#include "ECU1_sensor.h"
#include "DIGITAL_KEYPAD.h"
#include "msg_ID.h"

void init_config()
{
    init_adc();               // Initialize ADC module
    init_digital_keypad();    // Initialize digital keypad
    init_can();               // Initialize CAN module
}

void main(void)
{
    init_config();            // Call configuration initialization
    
    uint16_t speed;           // Variable to store speed value
    uint8_t data[8];          // CAN data buffer
    
    unsigned char gear;      // Variable to store gear position
    
    while(1)
    {    
        speed = get_speed();   // Read vehicle speed
        
        can_transmit(SPEED_MSG_ID, (uint8_t*)&speed, 1);   // Transmit speed over CAN
        
        for(int wait = 100; wait--;);   // Small delay
        
        gear = get_gear_pos();   // Read gear position
        
        can_transmit(GEAR_MSG_ID, &gear, 1);   // Transmit gear data over CAN
        
        for(int wait = 200; wait--;);   // Small delay
    }
    
}
