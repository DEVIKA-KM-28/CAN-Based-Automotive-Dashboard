/*
 * File:   ECU2_sensor.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:37 PM
 */

#include <xc.h>
#include "ADC.h"
#include "CAN.h"
#include "ECU2_sensor.h"
#include "DIGITAL_KEYPAD.h"
#include "msg_ID.h"

volatile IndicatorStatus prev_ind_status, cur_ind_status;   // Variables to store indicator states

void init_config()
{
    init_can();               // Initialize CAN module
    init_adc();               // Initialize ADC module
    init_digital_keypad();    // Initialize digital keypad
}

void main(void)
{
    init_config();   // Call initialization function
    
    uint16_t rpm;            // Variable to store RPM value
    unsigned char indicator; // Variable to store indicator status
    uint8_t data[8];         // CAN data buffer
    
    while(1)
    {
        rpm = get_rpm();   // Read RPM value
        
        can_transmit(RPM_MSG_ID, (uint8_t*)&rpm, 1);   // Transmit RPM data
        
        for(int wait = 300; wait--;);   // Small delay
        
        indicator = process_indicator();   // Process indicator status
        
        data[0] = indicator;   // Store indicator status in CAN data buffer
        
        can_transmit(INDICATOR_MSG_ID, data, 1);   // Transmit indicator data
        
        for(int wait = 400; wait--;);   // Small delay
    }
}
    