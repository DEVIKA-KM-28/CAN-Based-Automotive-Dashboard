/* 
 * File:   ECU2_sensor.h
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:37 PM
 */

#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>          // Standard integer type definitions
#include "DIGITAL_KEYPAD.h" // Header file for digital keypad
#include <xc.h>              // PIC microcontroller header file

#define RPM_ADC_CHANNEL 0x04        // ADC channel used for RPM sensor
#define ENG_TEMP_ADC_CHANNEL 0x06   // ADC channel used for engine temperature sensor

#define LED_OFF 0   // LED OFF state
#define LED_ON 1    // LED ON state

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)     // Turn ON right indicator LEDs
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)   // Turn OFF right indicator LEDs
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)      // Turn ON left indicator LEDs
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)    // Turn OFF left indicator LEDs

typedef enum {
    e_ind_off,     // Indicator OFF state
    e_ind_left,    // Left indicator ON state
    e_ind_right,   // Right indicator ON state
    e_ind_both     // Both indicators ON state
} IndicatorStatus;

uint16_t get_rpm();   // Function to get RPM value
IndicatorStatus process_indicator();   // Function to process indicator status

volatile IndicatorStatus prev_ind_status, cur_ind_status;   // Variables to store indicator states

#endif	/* ECU2_SENSOR_H */

