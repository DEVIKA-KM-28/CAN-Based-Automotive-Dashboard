/*
 * File:   ECU2_main.c
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:36 PM
 */

#include <xc.h>
#include "ECU2_sensor.h"
#include "DIGITAL_KEYPAD.h"
#include "ADC.h"
#include "msg_ID.h"
#include "CAN.h"

extern volatile IndicatorStatus prev_ind_status;   // Previous indicator status
extern volatile IndicatorStatus cur_ind_status;    // Current indicator status

uint16_t get_rpm()
{
    // Implement the RPM function
    
    uint16_t adc_value = read_adc(CHANNEL4);   // Read ADC value from RPM sensor channel
    
    return (adc_value / 10.23);   // Convert ADC value to RPM scale
}

IndicatorStatus process_indicator()
{    
    unsigned char key = read_digital_keypad(STATE_CHANGE);   // Read keypad input
    
    prev_ind_status = cur_ind_status;   // Store previous indicator status
    
    if(key == SWITCH1)
    {
        cur_ind_status = e_ind_left;   // Set left indicator status
    }
    else if(key == SWITCH2)
    {
        cur_ind_status = e_ind_right;   // Set right indicator status
    }
    else if(key == SWITCH3)
    {
        cur_ind_status = e_ind_off;   // Turn OFF indicators
    }
    else if(key == SWITCH4)
    {
        cur_ind_status = e_ind_both;   // Turn ON both indicators
    }
    
    if(cur_ind_status == e_ind_left)
    {
        LEFT_IND_ON();    // Turn ON left indicator
        RIGHT_IND_OFF();  // Turn OFF right indicator
    }
    else if(cur_ind_status == e_ind_right)
    {
        RIGHT_IND_ON();   // Turn ON right indicator
        LEFT_IND_OFF();   // Turn OFF left indicator
    }
    else if(cur_ind_status == e_ind_both)
    {
        RIGHT_IND_ON();   // Turn ON right indicator
        LEFT_IND_ON();    // Turn ON left indicator
    }
    else
    {
        RIGHT_IND_OFF();  // Turn OFF right indicator
        LEFT_IND_OFF();   // Turn OFF left indicator
    }
    
    return cur_ind_status;   // Return current indicator status
}