/* 
 * File:   CAN.h
 * Author: kmdev
 *
 * Created on 1 May, 2026, 10:35 PM
 */

#ifndef CAN_H
#define	CAN_H

#include <stdint.h>   // Standard integer type definitions

/* Defines ECAN */
#define   F_ECAN_MODE2_FP		CANCON & 0x0F          // Get current ECAN operating mode
#define   F_ECANFIFO_0			RXB0CONbits.RXFUL     // Check RX buffer 0 full flag
#define   F_ECANFIFO_1			RXB1CONbits.RXFUL     // Check RX buffer 1 full flag
#define   F_ECANFIFO_2			B0CONbits.RXFUL       // Check RX buffer 2 full flag
#define   F_ECANFIFO_3			B1CONbits.RXFUL       // Check RX buffer 3 full flag
#define   F_ECANFIFO_4			B2CONbits.RXFUL       // Check RX buffer 4 full flag
#define   F_ECANFIFO_5			B3CONbits.RXFUL       // Check RX buffer 5 full flag
#define   F_ECANFIFO_6			B4CONbits.RXFUL       // Check RX buffer 6 full flag
#define   F_ECANFIFO_7			B5CONbits.RXFUL       // Check RX buffer 7 full flag

#define CAN_SET_OPERATION_MODE_NO_WAIT(mode)		\
{													\
	CANCON &= 0x1F;									\
	CANCON |= mode;									\
}   // Set CAN operation mode

#define EIDH					0   // Extended ID high byte index
#define EIDL					1   // Extended ID low byte index
#define SIDH					2   // Standard ID high byte index
#define SIDL					3   // Standard ID low byte index
#define DLC						4   // Data Length Code index
#define D0						5   // Data byte 0 index
#define D1						6   // Data byte 1 index
#define D2						7   // Data byte 2 index
#define D3						8   // Data byte 3 index
#define D4						9   // Data byte 4 index
#define D5						10  // Data byte 5 index
#define D6						11  // Data byte 6 index
#define D7						12  // Data byte 7 index

/* Function Prototypes  */
void init_can(void);   // Initialize CAN module
void can_transmit(uint16_t msg_id, const uint8_t *data, uint8_t len);   // Transmit CAN message
void can_receive(uint16_t *msg_id, uint8_t *data, uint8_t *len);   // Receive CAN message

#endif	/* CAN_H */

