/*
 * File:   message_handler.c
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:02 PM
 */


#include <xc.h>
#include <stdint.h>
#include "CAN.h"
#include "CLCD.h"
#include "message_handler.h"
#include "msg_id.h"
#include "timer0.h"

extern volatile uint8_t flag;   // Flag variable for indicator blinking

void handle_speed_data(uint8_t *data, uint8_t len)
{
    uint8_t speed = (*data);   // Extract speed data
    
    clcd_print("SPD", LINE1(0));   // Display label
    
    clcd_putch(speed / 100 + '0', LINE2(0));        // Display hundreds digit
    clcd_putch((speed / 10) % 10 + '0', LINE2(1)); // Display tens digit
    clcd_putch((speed % 10) + '0', LINE2(2));      // Display units digit
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    clcd_print("GR", LINE1(4));   // Display gear label
    
    if(data[0] == 0)
    {
         clcd_putch('N', LINE2(4));   // Display Neutral gear
    }
    else
    {
        clcd_putch(data[0] + '0', LINE2(4));   // Display gear number
    }
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    // Implement the RPM function
    
    uint16_t rpm = (*data) * 60;   // Convert received value to RPM
    
    clcd_print("RPM", LINE1(7));   // Display RPM label
    
    clcd_putch(rpm / 1000 + '0', LINE2(7));         // Display thousands digit
    clcd_putch((rpm / 100) % 10 + '0', LINE2(8));  // Display hundreds digit
    clcd_putch((rpm / 10) % 10 + '0', LINE2(9));   // Display tens digit
    clcd_putch((rpm % 10) + '0', LINE2(10));       // Display units digit
}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    // Implement the indicator function
    
    clcd_print("IND", LINE1(11));   // Display indicator label
    
    if(flag == 1)
    {
        if(data[0] == e_ind_left)
        {
            clcd_print("<-- ", LINE2(11));   // Display left indicator
            
            LEFT_IND_ON();    // Turn ON left indicator LED
            RIGHT_IND_OFF();  // Turn OFF right indicator LED
        }
        else if(data[0] == e_ind_right)
        {
            clcd_print("--> ", LINE2(11));   // Display right indicator
            
            LEFT_IND_OFF();   // Turn OFF left indicator LED
            RIGHT_IND_ON();   // Turn ON right indicator LED
        }
        else if(data[0] == e_ind_both)
        {
            clcd_print("<-->", LINE2(11));   // Display both indicators
            
            LEFT_IND_ON();    // Turn ON left indicator LED
            RIGHT_IND_ON();   // Turn ON right indicator LED
        }
        else if(data[0] == e_ind_off)
        {
            clcd_print("    ", LINE2(11));   // Clear indicator display
            
            LEFT_IND_OFF();   // Turn OFF left indicator LED
            RIGHT_IND_OFF();  // Turn OFF right indicator LED
        }
    }
    else
    {
        clcd_print("    ", LINE2(11));   // Clear indicator display
        
        LEFT_IND_OFF();   // Turn OFF left indicator LED
        RIGHT_IND_OFF();  // Turn OFF right indicator LED
    }
}

void process_canbus_data(void) 
{   
    // Process the CAN bus data
    
    uint16_t msg_id;   // Variable to store message ID
    uint8_t  data;     // Variable to store received data
    uint8_t  len;      // Variable to store data length

    can_receive(&msg_id, &data, &len);   // Receive CAN message

    switch (msg_id)
    {
        case SPEED_MSG_ID:     
            handle_speed_data(&data, len);   // Handle speed message
            break;
            
        case GEAR_MSG_ID:     
            handle_gear_data(&data, len);    // Handle gear message
            break;
            
        case RPM_MSG_ID:       
            handle_rpm_data(&data, len);     // Handle RPM message
            break;
            
        case INDICATOR_MSG_ID: 
            handle_indicator_data(&data, len);   // Handle indicator message
            break;
            
        default:        
            break;   // Ignore unknown messages
    }
}
