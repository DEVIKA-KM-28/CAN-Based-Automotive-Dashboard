/*
 * File:   main.c
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:01 PM
 */


#include <xc.h>

#include <stdint.h>
#include "CAN.h"
#include "CLCD.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"

static int init_leds()
{
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) 
{
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();

    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}
void main(void)
{
    
    init_config();
  

    while (1) 
    {
        // Read CAN Bus data and handle it
        process_canbus_data();     
    }
}


