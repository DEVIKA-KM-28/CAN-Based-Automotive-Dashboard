/* 
 * File:   timer0.h
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:03 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H

void init_timer0(void);

#endif	/* TIMER0_H */

