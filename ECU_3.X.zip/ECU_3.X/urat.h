/* 
 * File:   urat.h
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:04 PM
 */

#ifndef URAT_H
#define	URAT_H

#define RX_PIN					TRISC7
#define TX_PIN					TRISC6

void init_uart(void);
void putch(unsigned char byte);
int puts(const char *s);
unsigned char getch(void);
unsigned char getch_with_timeout(unsigned short max_time);
unsigned char getche(void);

#endif	/* URAT_H */

