/* 
 * File:   message_handler.h
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:02 PM
 */

#ifndef MESSAGE_HANDLER_H
#define	MESSAGE_HANDLER_H

#include <stdint.h>

#define LED_OFF 0
#define LED_ON 1

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)     // sets RB6 and RB7

#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)    // clears RB6 and RB7

#define LEFT_IND_ON() (PORTB = PORTB | 0x03)       // sets RB0 and RB1

#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)     // clears RB0 and RB1

//extern volatile unsigned char led_state, status;

typedef enum 
{
    e_ind_off,
    e_ind_left,
    e_ind_right,
    e_ind_both
} IndicatorStatus;

void process_canbus_data();
void handle_speed_data(uint8_t *data, uint8_t len);
void handle_gear_data(uint8_t *data, uint8_t len);
void handle_rpm_data(uint8_t *data, uint8_t len);
void handle_indicator_data(uint8_t *data, uint8_t len);

#endif	/* MESSAGE_HANDLER_H */

