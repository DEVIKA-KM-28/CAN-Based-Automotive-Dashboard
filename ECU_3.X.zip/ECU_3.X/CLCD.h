/* 
 * File:   CLCD.h
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:01 PM
 */

#ifndef CLCD_H
#define	CLCD_H

#define CLCD_PORT			PORTD   // Port connected to CLCD data pins
#define CLCD_EN				RC2     // Enable pin of CLCD
#define CLCD_RS				RC1     // Register Select pin of CLCD
#define CLCD_RW				RC0     // Read/Write pin of CLCD
#define CLCD_BUSY			RD7     // Busy flag pin of CLCD
#define PORT_DIR			TRISD7  // Direction control for busy flag pin

#define HI					1       // Logic HIGH
#define LO					0       // Logic LOW

#define INPUT				0xFF    // Configure port as input
#define OUTPUT				0x00    // Configure port as output

#define DATA_COMMAND			1   // Data mode selection
#define INSTRUCTION_COMMAND		0   // Instruction mode selection

#define LINE1(x)			(0x80 + (x))   // Address for line 1
#define LINE2(x)			(0xC0 + (x))   // Address for line 2

#define TWO_LINE_5x8_MATRIX_8_BIT	clcd_write(0x38, INSTRUCTION_COMMAND)   // Initialize CLCD in 8-bit mode
#define CLEAR_DISP_SCREEN		clcd_write(0x01, INSTRUCTION_COMMAND)   // Clear display screen
#define CURSOR_HOME			clcd_write(0x02, INSTRUCTION_COMMAND)   // Move cursor to home position
#define DISP_ON_AND_CURSOR_OFF	clcd_write(0x0C, INSTRUCTION_COMMAND)   // Display ON and cursor OFF

void init_clcd(void);   // Function to initialize CLCD
void clcd_print(const unsigned char *data, unsigned char addr);   // Function to print string on CLCD
void clcd_putch(const unsigned char data, unsigned char addr);   // Function to print character on CLCD
void clcd_write(unsigned char bit_values, unsigned char control_bit);   // Function to send command/data to CLCD

#endif	/* CLCD_H */