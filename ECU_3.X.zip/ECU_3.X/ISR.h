/* 
 * File:   ISR.h
 * Author: kmdev
 *
 * Created on 6 May, 2026, 8:55 AM
 */

#ifndef ISR_H
#define	ISR_H

#include <stdint.h>

extern volatile uint8_t flag;

#endif	/* ISR_H */

