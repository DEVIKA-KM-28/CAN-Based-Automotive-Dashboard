/* 
 * File:   msg_id.h
 * Author: kmdev
 *
 * Created on 5 May, 2026, 12:03 PM
 */

#ifndef MSG_ID_H
#define	MSG_ID_H

#define SPEED_MSG_ID     0x10         // CAN message ID for speed data
#define GEAR_MSG_ID      0x20          // CAN message ID for gear position data
#define RPM_MSG_ID       0x30           // CAN message ID for RPM data
#define ENG_TEMP_MSG_ID  0x40      // CAN message ID for engine temperature data
#define INDICATOR_MSG_ID 0x50     // CAN message ID for indicator status data

#endif	/* MSG_ID_H */

