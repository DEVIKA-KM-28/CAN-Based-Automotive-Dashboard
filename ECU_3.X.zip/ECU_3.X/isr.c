/*
 * File:   isr.c
 * Author: kmdev
 *
 * Created on 6 May, 2026, 12:17 AM
 */


#include <xc.h>
#include <stdint.h>

volatile uint8_t flag;   // Flag variable for blinking control

void __interrupt() isr()
{
    static unsigned count = 0;   // Counter variable for delay
    
    if(TMR0IF == 1)   // Check Timer0 overflow interrupt flag
    {
        TMR0 = TMR0 + 8;   // Reload Timer0 value
        
        if(++count == 10000)   // Check delay count
        {
            flag = !flag;   // Toggle flag value
            count = 0;      // Reset counter
        }
        
        TMR0IF = 0;   // Clear Timer0 interrupt flag
    }
}